//
//  InsertionSort.h
//  Algorithms
//
//  Created by R3alFr3e on 1/16/14.
//  Copyright (c) 2014 R3alFr3e. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface InsertionSort : NSObject

+ (void)sort:(NSMutableArray *)array;

@end
