fibo
====

fibo.c:
	a usual implementation where a function is called and it prints 'count' number of elements of Fibonacci series that is passed as the argument

fibo_r.c:
	a "reentrant" C implementation to return successive elements on repetitive calls
