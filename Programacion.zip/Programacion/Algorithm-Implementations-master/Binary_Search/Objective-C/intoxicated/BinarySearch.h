//
//  BinarySearch.h
//  Algorithms
//
//  Created by intoxicated on 1/5/14.
//  Copyright (c) 2014 intoxicated. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BinarySearch : NSObject

+ (NSInteger)search:(NSArray *)array For:(NSInteger)value;

@end
