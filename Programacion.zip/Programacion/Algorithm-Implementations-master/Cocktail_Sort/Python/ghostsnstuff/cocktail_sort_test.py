from cocktail_sort import *
x = [11,33,15,190,4,23]
print "unsorted: ", x
print "sorted:   ", cocktailSort(x)
