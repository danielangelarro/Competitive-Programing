module EinsteinPuzzle_test (main) where
import EinsteinPuzzle

main = do
	putStrLn "The solution the Einstein Puzzle is: "
        putStrLn $ show $ solution
