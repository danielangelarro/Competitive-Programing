% You can run this file with the command swipl -l einstein_puzzle_test.pl

:- [einstein_puzzle].

:- writeln('This is a version of the Einstein Problem with a possible solution:').

:- main.

:- halt.
