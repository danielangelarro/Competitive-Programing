from bubble_sort import bubble_sort

arr = [3, 1, 5, 4, 20, 7, 6, 10, 9]

print arr
bubble_sort(arr)
print arr
