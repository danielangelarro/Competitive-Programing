//
//  BubbleSort.h
//  Algorithms
//
//  Created by intoxicated on 1/4/14.
//  Copyright (c) 2014 intoxicated. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BubbleSort : NSObject

+ (void)sort:(NSMutableArray *)array;

@end
