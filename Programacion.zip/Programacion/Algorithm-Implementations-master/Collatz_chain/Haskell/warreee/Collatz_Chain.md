A Collatz sequence or Collatz Chain is chain of numbers.

The algorithm:
Given any natural number
* If number = 1 stop
* If number is even then divide by 2
* If number is odd then multiply by 3 and add 1
* Repeat with resulting number
