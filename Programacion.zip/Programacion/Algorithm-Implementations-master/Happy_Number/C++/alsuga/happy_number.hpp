#ifndef HAPPY
#define HAPPY

bool is_happy_number(int input);

#endif

