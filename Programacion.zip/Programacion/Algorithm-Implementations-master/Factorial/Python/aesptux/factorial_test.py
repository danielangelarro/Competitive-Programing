import factorial

print factorial.factorial_recursive(0)
print factorial.factorial_recursive(1)
print factorial.factorial_recursive(5)
