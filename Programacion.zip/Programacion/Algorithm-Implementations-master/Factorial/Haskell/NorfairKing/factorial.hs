-- Note that this only produces the correct result when n is not negative.
fac n = product [ 2 .. n ]
