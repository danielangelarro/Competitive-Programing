from math import sqrt

def euclidean_norm(p):
    return sqrt(sum([u*u for u in p]))