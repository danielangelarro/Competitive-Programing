class EuclideanNormTest extends EuclideanNorm {
  public static void main(String[] args) {
    int[] v = {1,2,3,4};
    System.out.println(euclidean_norm(v)); // 5.477225575051661
  }
}
