var euclidean_norm = require('./euclidean_norm')
console.log(euclidean_norm([1,2,3,4]))
// (1^2 + 2^2 + 3^2 + 4^2)^1/2 = 5.4772
